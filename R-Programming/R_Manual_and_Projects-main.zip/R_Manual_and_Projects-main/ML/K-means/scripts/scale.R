# Skaalaa muuttujat
data_scaled <- scale(data)

# Tarkastele skaalattua dataa
head(data_scaled)
