# Lineaarinen regressiomalli
model <- lm(Sales ~ Advertising_Budget, data = data)

# Tulosta mallin yhteenveto
summary(model)
