# KAMK-AI-Studies / Tietorakenteet ja Algoritmit TTM23SAI

Essential Algorithms : A Practical Approach to Computer Algorithms
Tehtävät koodataan jupyterlab tai notebook alustalla ja palautetaan yhtenä etunimi_sukunimi_tehtävät1.ipynb tiedostona erillään muista tehtävä palautuksista Tehtävä palautukset laatikkoon.

Tehtävien pseudokoodit löydät kurssi kirjasta alla olevista sivunumeroista, tehtäväsi on tehdä näistä omaa toimivaa python koodia ja käyttää mahdollisimman vähän valmiita funktioita. s.09 Contains Duplicates s.20 Exercises 1 Contains Duplicates Improved Version s.31 Randomized array s.55-63 Linked List s.63-66 Double Linked List s.68 Insertionsort s.87 FindMinimum s.87 FindMaximum s.87 FindAverage s.87 FindMedian s.112 Push Stack s.112 Pop Stack s.117 Reverse Array with a Stack.
